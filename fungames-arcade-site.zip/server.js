'use strict';
/*
 * Riftline game server (Step 4): one shared arena, two game modes, server-side combat.
 *
 * Modes: 'tdm' = Vanguard vs Horizon team deathmatch, 'ffa' = free-for-all.
 * Set the MODE environment variable to tdm, ffa, or leave it unset to alternate every match.
 *
 * client -> server   state {e,x,y,z,yaw,pitch} ~20x/s   shoot {ox,oy,oz,dx,dy,dz}   reload   name 'text'
 * server -> client   welcome, join, leave, rename, factions, match      who is here, what mode is on
 *                    snapshot [[id,x,y,z,yaw,pitch,alive]] 20x/s         where everyone is
 *                    you {hp,ammo,reloading}   hit {kill}   fx {a,b,f}   your health/ammo, hit confirm, other people's tracers
 *                    kill {k,v,kn,vn,kf,vf,r}   scores {t,p}   respawn   the feed and scoreboard
 *
 * The server decides every hit, every kill and every point. Positions are still reported by each client
 * and only sanity-checked, so a modified client could move impossibly fast. Server-side movement is the next upgrade.
 */
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
// The arcade site lives on a different host than this server, so list its address(es) here.
// Any http://localhost:<port> is always allowed for local testing.
const ORIGINS = (process.env.ALLOWED_ORIGINS || 'https://fungames-arcade.netlify.app').split(',').map(s => s.trim());
const MODE = ['tdm', 'ffa'].includes(process.env.MODE) ? process.env.MODE : 'rotate';
const TICK_HZ = 20, MAX_PLAYERS = 16, ARENA_HALF = 60;
const WEAPON = { damage: 20, fireRate: 6, range: 150, mag: 12, reloadMs: 1500 };
const HP = 100, RESPAWN_MS = 3000, INTERMISSION_MS = 8000;
const LIMIT = { tdm: Number(process.env.TDM_LIMIT) || 20, ffa: Number(process.env.FFA_LIMIT) || 10 };   // kills needed to win
const BODY = { r: .4, h: 1.8, eye: 1.62 };
const SPAWNS = [[4, 4], [-4, 4], [4, -4], [-4, -4], [0, 8], [8, 2], [-8, 2], [0, -6]];
// Must match CONFIG.obstacles in riftline/index.html until both live in one shared file.
const OBSTACLES = [
  { x: 0,   z: -14, hx: 1.5, hz: 1.5, h: 3 },
  { x: -8,  z: -9,  hx: 1,   hz: 1,   h: 1 },
  { x: 8,   z: -9,  hx: 1,   hz: 3,   h: 2 },
  { x: -14, z: -22, hx: 3,   hz: 1,   h: 2.5 },
  { x: 14,  z: -24, hx: 2,   hz: 2,   h: 4 },
  { x: 0,   z: 14,  hx: 1.5, hz: 1.5, h: 2 }
];

const players = new Map();   // socket.id -> player
const match = { mode: 'tdm', state: 'live', team: { vanguard: 0, horizon: 0 } };
let nextId = 1, spawnIx = 0, tick = 0;

const app = express();
if (process.env.SITE_DIR) app.use(express.static(path.resolve(process.env.SITE_DIR)));   // optional: serve the arcade locally too
app.get('/health', (req, res) => res.json({ ok: true, players: players.size, mode: match.mode }));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: (origin, cb) => cb(null, !origin || ORIGINS.includes(origin) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) },
  maxHttpBufferSize: 1e4
});

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const r2 = v => Math.round(v * 100) / 100, r3 = v => Math.round(v * 1000) / 1000;
const pub = p => ({ id: p.id, name: p.name, faction: p.faction, kills: p.kills, deaths: p.deaths, alive: p.alive, x: p.x, y: p.y, z: p.z, yaw: p.yaw, pitch: p.pitch });
const matchInfo = () => ({ mode: match.mode, limit: LIMIT[match.mode], state: match.state, team: match.team });
const sendScores = () => io.emit('scores', { t: match.team, p: [...players.values()].map(p => [p.id, p.kills, p.deaths]) });
const cleanName = (n, id) => (typeof n === 'string' ? n.replace(/[^\p{L}\p{N} _.-]/gu, '').trim().slice(0, 14) : '') || 'Pilot ' + id;

// New players: random side in team deathmatch, but if the teams are uneven the smaller one gets them.
function pickFaction() {
  if (match.mode !== 'tdm') return 'ffa';
  let v = 0, h = 0;
  for (const p of players.values()) { if (p.faction === 'vanguard') v++; else if (p.faction === 'horizon') h++; }
  if (v === h) return Math.random() < .5 ? 'vanguard' : 'horizon';
  return v < h ? 'vanguard' : 'horizon';
}

function respawn(p) {
  const [x, z] = SPAWNS[Math.floor(Math.random() * SPAWNS.length)];
  Object.assign(p, { x, y: 0, z, hp: HP, alive: true, ammo: WEAPON.mag, reloadEnd: 0, nextShot: 0, epoch: p.epoch + 1, hist: [] });
  p.sock.emit('respawn', { x, z, hp: HP, ammo: WEAPON.mag, e: p.epoch });   // e: old position updates still in flight are ignored
}

function startReload(p) {
  if (p.reloadEnd || p.ammo >= WEAPON.mag) return;
  p.reloadEnd = Date.now() + WEAPON.reloadMs;
  p.sock.emit('you', { hp: p.hp, ammo: p.ammo, reloading: true });
}

// Ray against an axis-aligned box (slab method). Returns the distance along the ray, or null for a miss.
function rayBox(o, d, x0, y0, z0, x1, y1, z1) {
  const O = [o.x, o.y, o.z], D = [d.x, d.y, d.z], lo = [x0, y0, z0], hi = [x1, y1, z1];
  let tmin = 0, tmax = Infinity;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(D[i]) < 1e-9) { if (O[i] < lo[i] || O[i] > hi[i]) return null; continue; }
    let a = (lo[i] - O[i]) / D[i], b = (hi[i] - O[i]) / D[i];
    if (a > b) [a, b] = [b, a];
    tmin = Math.max(tmin, a); tmax = Math.min(tmax, b);
    if (tmin > tmax) return null;
  }
  return tmin;
}

// Where was this player at time t? Used to rewind targets to what the shooter was actually seeing (lag compensation).
function posAt(p, t) {
  const h = p.hist, n = h.length;
  if (!n || t >= h[n - 1].t) return p;
  if (t <= h[0].t) return h[0];
  let i = n - 1; while (i > 1 && h[i - 1].t > t) i--;
  const a = h[i - 1], b = h[i], k = (t - a.t) / ((b.t - a.t) || 1);
  return { x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k, z: a.z + (b.z - a.z) * k };
}

// Nearest thing the shot hits: the floor, a block, or a living enemy. Walls block shots.
function cast(shooter, o, d) {
  let best = { t: WEAPON.range, who: null };
  if (d.y < -1e-6) { const t = -o.y / d.y; if (t > 0 && t < best.t) best = { t, who: null }; }
  for (const b of OBSTACLES) {
    const t = rayBox(o, d, b.x - b.hx, 0, b.z - b.hz, b.x + b.hx, b.h, b.z + b.hz);
    if (t !== null && t < best.t) best = { t, who: null };
  }
  const when = Date.now() - Math.min(400, shooter.rtt + 100);   // round trip plus the 100 ms clients draw others in the past
  for (const p of players.values()) {
    if (p === shooter || !p.alive || (match.mode === 'tdm' && p.faction === shooter.faction)) continue;   // no friendly fire
    const q = posAt(p, when);
    const t = rayBox(o, d, q.x - BODY.r, q.y, q.z - BODY.r, q.x + BODY.r, q.y + BODY.h, q.z + BODY.r);
    if (t !== null && t < best.t) best = { t, who: p };
  }
  return best;
}

function hurt(shooter, target) {
  target.hp -= WEAPON.damage;
  const dead = target.hp <= 0;
  shooter.sock.emit('hit', { kill: dead });
  if (!dead) { target.sock.emit('you', { hp: target.hp, ammo: target.ammo, reloading: !!target.reloadEnd }); return; }
  target.hp = 0; target.alive = false; target.deaths++; shooter.kills++; target.respawnAt = Date.now() + RESPAWN_MS;
  if (match.mode === 'tdm') match.team[shooter.faction]++;
  target.sock.emit('you', { hp: 0, ammo: target.ammo, reloading: false });
  io.emit('kill', { k: shooter.id, v: target.id, kn: shooter.name, vn: target.name, kf: shooter.faction, vf: target.faction, r: RESPAWN_MS });
  sendScores();
  if (match.mode === 'tdm' && match.team[shooter.faction] >= LIMIT.tdm) endMatch(shooter.faction.toUpperCase() + ' WINS', shooter.faction);
  else if (match.mode === 'ffa' && shooter.kills >= LIMIT.ffa) endMatch(shooter.name + ' WINS', 'ffa');
}

function endMatch(winner, wf) {
  if (match.state !== 'live') return;
  match.state = 'over';
  const next = MODE === 'rotate' ? (match.mode === 'tdm' ? 'ffa' : 'tdm') : match.mode;
  io.emit('match', { ...matchInfo(), winner, wf, next, ms: INTERMISSION_MS });
  setTimeout(() => startMatch(next), INTERMISSION_MS);
}

function startMatch(mode) {
  match.mode = mode; match.state = 'live'; match.team = { vanguard: 0, horizon: 0 };
  const list = [...players.values()].sort(() => Math.random() - .5), flip = Math.random() < .5 ? 1 : 0;   // random split into teams
  list.forEach((p, i) => { p.kills = p.deaths = 0; p.faction = mode === 'tdm' ? ((i + flip) % 2 ? 'horizon' : 'vanguard') : 'ffa'; });
  io.emit('match', matchInfo());
  io.emit('factions', list.map(p => [p.id, p.faction]));
  for (const p of players.values()) respawn(p);
  sendScores();
}

io.on('connection', socket => {
  if (players.size >= MAX_PLAYERS) { socket.emit('full'); socket.disconnect(true); return; }
  const id = nextId++, [sx, sz] = SPAWNS[spawnIx++ % SPAWNS.length];
  const me = {
    id, sock: socket, name: 'Pilot ' + id, faction: pickFaction(), x: sx, y: 0, z: sz, yaw: 0, pitch: 0, last: 0,
    hp: HP, alive: true, kills: 0, deaths: 0, ammo: WEAPON.mag, reloadEnd: 0, nextShot: 0, respawnAt: 0, epoch: 0, rtt: 100, hist: [], nameAt: 0
  };
  players.set(socket.id, me);
  socket.emit('welcome', { ...pub(me), hp: me.hp, ammo: me.ammo, match: matchInfo(), players: [...players.values()].filter(p => p !== me).map(pub) });
  socket.broadcast.emit('join', pub(me));
  console.log(`+ ${me.name} (${me.faction}), ${players.size} online, ${match.mode}`);

  socket.on('state', d => {
    const now = Date.now();
    if (!d || !me.alive || d.e !== me.epoch || now - me.last < 15) return;     // dead, stale (before a respawn) or flooding
    if (![d.x, d.y, d.z, d.yaw, d.pitch].every(n => typeof n === 'number' && Number.isFinite(n))) return;
    me.last = now;
    me.x = r2(clamp(d.x, -ARENA_HALF, ARENA_HALF)); me.y = r2(clamp(d.y, 0, 30)); me.z = r2(clamp(d.z, -ARENA_HALF, ARENA_HALF));
    me.yaw = r3(clamp(d.yaw, -Math.PI, Math.PI)); me.pitch = r3(clamp(d.pitch, -Math.PI / 2, Math.PI / 2));
  });

  socket.on('shoot', d => {
    const now = Date.now();
    if (!d || !me.alive || match.state !== 'live' || me.reloadEnd || now < me.nextShot) return;   // fire rate and reload are enforced here
    if (!['ox', 'oy', 'oz', 'dx', 'dy', 'dz'].every(k => typeof d[k] === 'number' && Number.isFinite(d[k]))) return;
    const len = Math.hypot(d.dx, d.dy, d.dz);
    if (len < .5) return;
    const o = { x: d.ox, y: d.oy, z: d.oz }, dir = { x: d.dx / len, y: d.dy / len, z: d.dz / len };
    if (Math.hypot(o.x - me.x, o.y - (me.y + BODY.eye), o.z - me.z) > 6) return;   // the ray must start near the shooter
    if (me.ammo <= 0) { startReload(me); return; }
    me.nextShot = now + (1000 / WEAPON.fireRate) * .8; me.ammo--;
    const hit = cast(me, o, dir), t = hit.t;
    socket.broadcast.emit('fx', {                                                    // let everyone else see the tracer
      a: [r2(me.x + dir.x * .7), r2(me.y + BODY.eye + dir.y * .7), r2(me.z + dir.z * .7)],
      b: [r2(o.x + dir.x * t), r2(o.y + dir.y * t), r2(o.z + dir.z * t)], f: me.faction
    });
    if (hit.who) hurt(me, hit.who);
    if (me.ammo <= 0) startReload(me);
  });

  socket.on('reload', () => { if (me.alive && match.state === 'live') startReload(me); });

  socket.on('name', n => {
    const now = Date.now(), nm = cleanName(n, me.id);
    if (now - me.nameAt < 1000 || nm === me.name) return;
    me.nameAt = now; me.name = nm;
    io.emit('rename', { id: me.id, name: nm });
  });

  socket.on('disconnect', () => {
    players.delete(socket.id);
    io.emit('leave', me.id);
    console.log(`- ${me.name}, ${players.size} online`);
  });
});

// The heartbeat: 20 times a second. Records history for lag compensation, finishes reloads, respawns the dead,
// measures each player's round-trip time, and sends everybody one snapshot.
setInterval(() => {
  const now = Date.now(); tick++;
  for (const p of players.values()) {
    if (p.alive) { p.hist.push({ t: now, x: p.x, y: p.y, z: p.z }); if (p.hist.length > 25) p.hist.shift(); }
    else if (match.state === 'live' && now >= p.respawnAt) respawn(p);
    if (p.reloadEnd && now >= p.reloadEnd) { p.reloadEnd = 0; p.ammo = WEAPON.mag; p.sock.emit('you', { hp: p.hp, ammo: p.ammo, reloading: false }); }
    if (tick % (TICK_HZ * 2) === 0) { const t0 = now; p.sock.emit('lag', () => { p.rtt = Math.min(1000, Date.now() - t0); }); }
  }
  if (!players.size) return;
  const list = [...players.values()].map(p => [p.id, p.x, p.y, p.z, p.yaw, p.pitch, p.alive ? 1 : 0]);
  for (const s of io.sockets.sockets.values()) s.volatile.emit('snapshot', list);
}, 1000 / TICK_HZ);

startMatch(MODE === 'rotate' ? 'tdm' : MODE);
server.listen(PORT, () => console.log(`Riftline server listening on port ${PORT}, mode ${MODE}`));
